#! /bin/bash

echo "INSTALADOR"

cd proyecto_final
cd cal
mkdir build
cd build
cmake ..
make 
./proyecto2

//Algebraic operations
float suma(float A, float B);
float resta(float A, float B);
float multi(float A, float B);
float div(float A, float B); 

#include "library.h"

float suma(float A, float B)
{
  float C = A + B;
  return C;
}

float resta(float A, float B)
{
  float C = A - B;
  return C;
}

float multi(float A, float B)
{
  float C = A*B;
  return C;
}

float div(float A, float B)
{
  float C = A/B;
  return C;
}

#! /bin/bash

echo "INSTALADOR"

cd proyecto_final
cd animation
mkdir build
cd build
cmake ..
make 
./animation

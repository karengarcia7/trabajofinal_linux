#include "ejemplo.hpp"

void bienvenida(std::string cadena)
{

	std::cout << cadena << std::endl;

}

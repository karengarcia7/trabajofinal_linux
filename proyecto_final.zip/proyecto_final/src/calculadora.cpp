#include <math.h>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ejemplo.hpp>
using namespace std;


int main(){

    
	int operacion;
	float num1,num2,r;
  
	bienvenida("BIENVENIDO A LA CALCULADORA DE DOS OPERANDOS");

	cout<< "Seleccione una operacion: "<< endl<<endl;
	cout<< "Suma = 1"<< endl;
	cout<< "Resta = 2"<< endl;
	cout<< "Multiplicacion = 3"<< endl;
	cout<< "Division = 4"<< endl;
	cout<< "Potencia = 5"<< endl<<endl;


	cin>>operacion;
	cout<< "Primer numero:"<<endl;
	cin>>num1;
	cout<< "segundo numero:"<<endl<<endl;
	cin>>num2;

		if (operacion== 1 ) { r=num1+num2; }
		else
		if (operacion== 2 ) { r=num1-num2; }
		else
		if (operacion== 3 ) { r=num1*num2; }
		else
		if (operacion== 4 ) { r=num1/num2; }
		else
		if (operacion== 5 ) { r=num1*num1; r=num2*num2 ; }
	cout<<"El Resultado de su operacion es:"<<r<<endl;

return(0);

}

#include <stdio.h>
#include <iostream>


 
void bienvenida(std::string cadena);
